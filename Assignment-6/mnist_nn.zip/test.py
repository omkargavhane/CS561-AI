import mnist_loader
import network
import matplotlib.pyplot as plt
def test(hidden_nodes):
    training_data, validation_data, test_data=mnist_loader.load_data_wrapper()
    net = network.Network([784, 30, 10])
    return net.SGD(training_data, 30, 10, 3.0, test_data=test_data)

hidden_nodes=[30,40,50,60,70,80,90,100]
accuracys=[]
for e in hidden_nodes:
    print("Hidden Nodes : ",e)
    accuracys.append(test(e))
accuracy=[]
for e in accuracys:
    accuracy.append(max(e))
plt.plot(hidden_nodes,accuracy)
plt.xlabel("Hidden Nodes")
plt.ylabel("Accuracy")
plt.title("Hidden nodes vs Accuracy")
plt.show()
