valid(Premise, Conclusion) :-
    valid(Premise->Conclusion).

valid(Prop) :-
    unsatisfiable(\+Prop).

unsatisfiable(Prop) :-
    \+ true(Prop).

true(v(true)).
true(\+ Prop) :-
    false(Prop).
    
true((X;Y)) :-
    ( true(X)
    ; true(Y)
    ).

true((X,Y)) :-
    true(X),
    true(Y).

true((X->Y)) :-
    ( false(X)
    ; true(Y)
    ).

true((X=:=Y)) :-
    ( true(X),
      true(Y)
    ; false(X),
      false(Y)
    ).

false(v(false)).
false(\+ Prop) :-
    true(Prop).

false((X;Y)) :-
    false(X),
    false(Y).

false((X,Y)) :-
    ( false(X)
    ; false(Y)
    ).

false((X->Y)) :-
    true(X),
    false(Y).

false((X=:=Y)) :-
    ( true(X),
      false(Y)
    ; false(X),
      true(Y)
    ).