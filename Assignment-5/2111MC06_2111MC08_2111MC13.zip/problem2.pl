:- style_check(-singleton).
/* A ,B,C belong to Himalayan Club*/
belong(a).
belong(b).
belong(c).

/*belong(X):-notmc(X),notsk(X),!,fail.belong(X).*/ 
/* A likes Rain and Snow*/
like(a,rain).
like(a,snow).
 
/*A likes whatever B dislikes and dislikes whatever B likes*/
like(a,X):-dislike(b,X).
 
/* this condition will terminate the search */
like(b,X):-like(a,X),!,fail.
like(b,X).
 
mc(X):-like(X,rain),!,fail.
mc(X).
notsk(X):-dislike(X,snow).
notmc(X):-mc(X),!,fail.
notmc(X).
 
dislike(P,Q):-like(P,Q),!,fail.
dislike(P,Q).


